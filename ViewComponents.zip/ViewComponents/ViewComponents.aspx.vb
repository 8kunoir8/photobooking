﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Web.UI
Imports DevExpress.Web
Imports System.Data.SqlClient
Imports DevExpress.Export
Imports DevExpress.XtraPrinting
Imports DevExpress.Web.ASPxGridView

Public Class ViewComponents
    Inherits System.Web.UI.Page

    Protected Sub UsersGrid_BeforePerformDataSelect(sender As Object, e As EventArgs)
        Session("ComponentId") = (TryCast(sender, ASPxGridView)).GetMasterRowKeyValue()
    End Sub

    Protected Sub LoggedGrid_BeforePerformDataSelect(sender As Object, e As EventArgs)
        Session("ComponentId") = (TryCast(sender, ASPxGridView)).GetMasterRowKeyValue()
    End Sub
    Protected Sub LoggedGrid_CustomButtonCallback(sender As Object, e As ASPxGridViewCustomButtonCallbackEventArgs)
        If e.ButtonID = "cmdLogOut" Then

            Dim expandedRowKey As Integer = Convert.ToInt32(Session("ComponentId"))
            Dim VisIndex As Integer = GridComponents.FindVisibleIndexByKeyValue(expandedRowKey)
            Dim detailGrid As ASPxGridView = TryCast(GridComponents.FindDetailRowTemplateControl(VisIndex, "LoggedGrid"), ASPxGridView)
            Dim LogUserID As Integer = CInt(detailGrid.GetSelectedFieldValues("UserID").ToString())

            If Not IsNothing(detailGrid) Then
                If MsgBox("You are about to Log " & LogUserID & " Out Of " & CStr(Session("ComponentId")) & vbCrLf & "Do You want to Continue?", MsgBoxStyle.OkCancel) = MsgBoxResult.Ok Then
                    If UserHelper.LogUserOut(LogUserID, Session("ComponentId")) = True Then
                        MsgBox(CStr(LogUserID) & " has been logged out of " & CStr(Session("ComponentId")))
                    End If

                End If
            End If
        End If
    End Sub
End Class